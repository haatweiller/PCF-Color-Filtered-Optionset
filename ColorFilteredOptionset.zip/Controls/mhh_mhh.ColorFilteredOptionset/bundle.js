/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ColorFilteredOptionset/index.ts":
/*!*****************************************!*\
  !*** ./ColorFilteredOptionset/index.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ColorFilteredOptionset: () => (/* binding */ ColorFilteredOptionset)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_FilteredOptionsetComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/FilteredOptionsetComponent */ \"./components/FilteredOptionsetComponent.tsx\");\n/* harmony import */ var _components_fallbackTheme__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/fallbackTheme */ \"./components/fallbackTheme.ts\");\n\n\n\nclass ColorFilteredOptionset {\n  /**\r\n   * Empty constructor.\r\n   */\n  constructor() {\n    this.onChange = newValue => {\n      if (newValue !== undefined && (newValue === null || newValue === void 0 ? void 0 : newValue.length) > 0) this.selectedValue = Number(newValue[0]);else this.selectedValue = undefined;\n      this.notifyOutputChanged();\n    };\n    // empty\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.context = context;\n    this.context.mode.trackContainerResize(true);\n  }\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  updateView(context) {\n    var _a, _b, _c, _d;\n    var value = context.parameters.value;\n    var hideChoice = context.parameters.hideChoice;\n    var hideSpecificColor = context.parameters.hideSpecificColor;\n    var requiredLevel = (_a = value.attributes) === null || _a === void 0 ? void 0 : _a.RequiredLevel;\n    var disabled = context.mode.isControlDisabled;\n    var masked = false;\n    if (value.security) {\n      disabled = disabled || !value.security.editable;\n      masked = !value.security.readable;\n    }\n    var props = {\n      onChange: this.onChange,\n      options: [],\n      hideChoice: hideChoice.raw,\n      hideSpecificColor: (_b = hideSpecificColor.raw) !== null && _b !== void 0 ? _b : undefined,\n      isDisabled: disabled,\n      masked: masked,\n      isRequired: requiredLevel === 1 || requiredLevel === 2,\n      multiSelect: false,\n      theme: (_d = (_c = context.fluentDesignLanguage) === null || _c === void 0 ? void 0 : _c.tokenTheme) !== null && _d !== void 0 ? _d : _components_fallbackTheme__WEBPACK_IMPORTED_MODULE_2__.fallbackLightTheme\n    };\n    if (value && value.attributes) {\n      var options = value.attributes.Options;\n      if (options) {\n        props.options = options;\n        props.currentValue = value.raw;\n      }\n    }\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_FilteredOptionsetComponent__WEBPACK_IMPORTED_MODULE_1__.FilteredOptionsetComponent, props);\n  }\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  getOutputs() {\n    return {\n      value: this.selectedValue\n    };\n  }\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ColorFilteredOptionset/index.ts?");

/***/ }),

/***/ "./components/FilteredOptionsetComponent.tsx":
/*!***************************************************!*\
  !*** ./components/FilteredOptionsetComponent.tsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   FilteredOptionsetComponent: () => (/* binding */ FilteredOptionsetComponent)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__);\n\n\nvar FilteredOptionsetComponent = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.memo(props => {\n  var {\n    currentValue,\n    options,\n    isDisabled,\n    hideChoice,\n    hideSpecificColor,\n    onChange,\n    masked,\n    isRequired,\n    multiSelect\n  } = props;\n  var items = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {\n    var configError;\n    var selectedValue = typeof currentValue === \"number\" ? [currentValue] : currentValue !== null && currentValue !== void 0 ? currentValue : [];\n    if (options) {\n      if (hideChoice == \"hideSpecificColor\" && !hideSpecificColor) configError = \"Empty hideSpecificColor\";\n      return {\n        error: configError,\n        options: options.filter(item => {\n          var _a;\n          if (selectedValue.includes(item.Value)) {\n            return true;\n          } else {\n            if (hideChoice == \"hideColor\") {\n              return !item.Color;\n            } else if (hideChoice == \"hideNoColor\") {\n              return (_a = item.Color) !== null && _a !== void 0 ? _a : false;\n            } else if (hideChoice == \"hideSpecificColor\") {\n              return item.Color !== hideSpecificColor;\n            } else if (hideChoice == \"showSpecificColor\") {\n              return item.Color === hideSpecificColor;\n            }\n            return false;\n          }\n        }).map(item => {\n          return {\n            key: item.Value.toString(),\n            data: item.Value,\n            text: item.Label,\n            selected: selectedValue.includes(item.Value)\n          };\n        })\n      };\n    } else {\n      configError = 'No options found';\n      return {\n        error: configError,\n        options: []\n      };\n    }\n  }, [options, currentValue]);\n  var [selectedOptions, setSelectedOptions] = react__WEBPACK_IMPORTED_MODULE_0__.useState(() => {\n    var options = [];\n    items.options.filter(option => option.selected).forEach(option => options.push(option.key.toString()));\n    return options;\n  });\n  var [value, setValue] = react__WEBPACK_IMPORTED_MODULE_0__.useState(() => {\n    var options = [];\n    items.options.filter(option => option.selected).forEach(option => options.push(option.text));\n    return options.join(\", \");\n  });\n  var onOptionSelect = (ev, data) => {\n    items.options = items.options.map(item => {\n      return {\n        key: item.key,\n        data: item.data,\n        text: item.text,\n        selected: data.selectedOptions.includes(item.key.toString())\n      };\n    });\n    setSelectedOptions(data.selectedOptions);\n    setValue(() => {\n      var options = [];\n      items.options.filter(option => option.selected).forEach(option => options.push(option.text));\n      return options.join(\", \");\n    });\n    onChange(data.selectedOptions);\n  };\n  var styles = _useStyles();\n  var dropDownProps = {\n    disabled: isDisabled,\n    multiselect: multiSelect,\n    clearable: !isRequired,\n    value: value,\n    onOptionSelect: onOptionSelect,\n    className: styles.root,\n    selectedOptions: selectedOptions\n  };\n  if (selectedOptions.length == 0) {\n    dropDownProps.placeholder = '-- Select --';\n  }\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, items.error, masked && '****', !items.error && !masked && items.options && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.FluentProvider, {\n    theme: props.theme\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Dropdown, Object.assign({}, dropDownProps), items.options.map(option => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Option, {\n    key: option.key,\n    value: option.key.toString()\n  }, option.text)))))));\n});\nFilteredOptionsetComponent.displayName = 'FilteredOptionsetComponent';\nvar _useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.makeStyles)({\n  root: {\n    margin: \"auto 0\",\n    width: \"100%\"\n  }\n});\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./components/FilteredOptionsetComponent.tsx?");

/***/ }),

/***/ "./components/fallbackTheme.ts":
/*!*************************************!*\
  !*** ./components/fallbackTheme.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   fallbackDarkTheme: () => (/* binding */ fallbackDarkTheme),\n/* harmony export */   fallbackLightTheme: () => (/* binding */ fallbackLightTheme)\n/* harmony export */ });\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_0__);\n\nvar fallbackTheme = {\n  10: \"#020305\",\n  20: \"#111723\",\n  30: \"#16263D\",\n  40: \"#193253\",\n  50: \"#1B3F6A\",\n  60: \"#1B4C82\",\n  70: \"#18599B\",\n  80: \"#1267B4\",\n  90: \"#3174C2\",\n  100: \"#4F82C8\",\n  110: \"#6790CF\",\n  120: \"#7D9ED5\",\n  130: \"#92ACDC\",\n  140: \"#A6BAE2\",\n  150: \"#BAC9E9\",\n  160: \"#CDD8EF\"\n};\nvar fallbackLightTheme = Object.assign({}, (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_0__.createLightTheme)(fallbackTheme));\nvar fallbackDarkTheme = Object.assign({}, (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_0__.createDarkTheme)(fallbackTheme));\nfallbackDarkTheme.colorBrandForeground1 = fallbackTheme[110];\nfallbackDarkTheme.colorBrandForeground2 = fallbackTheme[120];\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./components/fallbackTheme.ts?");

/***/ }),

/***/ "@fluentui/react-components":
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
/***/ ((module) => {

module.exports = FluentUIReactv940;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./ColorFilteredOptionset/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('mhh.ColorFilteredOptionset', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ColorFilteredOptionset);
} else {
	var mhh = mhh || {};
	mhh.ColorFilteredOptionset = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ColorFilteredOptionset;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}